/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package marslander;

import basicgraphics.*;
import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

/**
 *
 * @author Js4fs
 */
public class MarsLander {
    public static void main(String[] args){
        BasicFrame bf = new BasicFrame("Mars Lander");
        SpriteComponent sc = new SpriteComponent();
        Dimension d = new Dimension(800, 400);
        sc.setPreferredSize(d);
        bf.createBasicLayout(sc);
        LandingPad lp = new LandingPad(sc);
        bf.show();
        Rocket rocket = new Rocket(sc);
        
        Clock.addTask(sc.moveSprites());
        Clock.start(10);
        
        KeyAdapter keys = new KeyAdapter(){ 
            public void keyPressed(KeyEvent k){
                if(k.getKeyCode() == KeyEvent.VK_UP){
                    rocket.setVelY(rocket.getVelY() - .04);
                    rocket.setPicture(rocket.rocketWithFlame);
                }
                if(k.getKeyCode() == KeyEvent.VK_RIGHT){
                    rocket.setVelX(rocket.getVelX() + .02);
                }
                if(k.getKeyCode() == KeyEvent.VK_LEFT){
                    rocket.setVelX(rocket.getVelX() - .02);
                }
            }
            
            public void keyReleased(KeyEvent k){
                rocket.setPicture(rocket.rocket);
            }
        };
        
        bf.addKeyListener(keys);
        
        sc.addSpriteSpriteCollisionListener(Rocket.class, LandingPad.class, new SpriteSpriteCollisionListener<Rocket, LandingPad>(){
            @Override
            public void collision(Rocket sp1, LandingPad sp2) {
                sp1.setActive(false);
                sp2.setActive(false);
                if(sp1.getVelX() > .1 || sp1.getVelX() < -.1){
                    JOptionPane.showMessageDialog(sc, "X-Velocity too large!" + sp1.getVelX());
                    System.exit(0);
                }
                else if(sp1.getVelY() > .4){
                    JOptionPane.showMessageDialog(sc, "Y-Velocity too large!" + sp1.getVelY());
                    System.exit(0);
                }
                else{
                    JOptionPane.showMessageDialog(sc, "You landed safely! You win!");
                    System.exit(0);
                }
                
            }
            
        });
    }
}

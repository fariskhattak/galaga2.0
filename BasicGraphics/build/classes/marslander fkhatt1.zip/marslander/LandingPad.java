/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package marslander;
import basicgraphics.*;
import basicgraphics.images.Picture;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
/**
 *
 * @author Js4fs
 */
public class LandingPad extends Sprite{
    public LandingPad(SpriteComponent sc){
        super(sc);
        BufferedImage im = BasicFrame.createImage(100, 20);
        Graphics g = im.getGraphics();
        g.setColor(Color.orange);
        g.fillRect(0, 0, 100, 20);
        setX(350);
        setY(380);
        Picture pad = new Picture(im);
        setPicture(pad);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package marslander;
import basicgraphics.*;
import basicgraphics.images.Picture;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.swing.JOptionPane;
/**
 *
 * @author Js4fs
 */
public class Rocket extends Sprite{
    Picture rocket;
    Picture rocketWithFlame;
    
    public Rocket(SpriteComponent sc) {
        super(sc);
        BufferedImage im = BasicFrame.createImage(20, 30);
        Graphics2D r = (Graphics2D) im.getGraphics();
        int w = im.getWidth();
        int h = im.getHeight();
        r.setColor(Color.blue);
        int[] x = {w/2, w, w, 0, 0};
        int[] y = {0, h/3, 2*h/3, 2*h/3, h/3};
        r.fillPolygon(x, y, 5);
        r.drawLine(0, 2*h/3, 0, h);
        r.drawLine(w-1, 2*h/3, w-1, h);
        rocket = new Picture(im);
        setPicture(rocket);
        setX(w/2);
        setY(h/2);
        
        BufferedImage im2 = BasicFrame.createImage(20, 30);
        Graphics2D r2 = (Graphics2D) im2.getGraphics();
        r2.setColor(Color.blue);
        r2.fillPolygon(x, y, 5);
        r2.drawLine(0, 2*h/3, 0, h);
        r2.drawLine(w-1, 2*h/3, w-1, h);
        r2.setColor(Color.orange);
        int[] x2 = {w/4, w/2, 3*w/4};
        int[] y2 = {2*h/3, h, 2*h/3};
        r2.fillPolygon(x2, y2, 3);
        rocketWithFlame = new Picture(im2);
        
        Task gravity = new Task(){
            @Override
            public void run() {
                setVelY(.002 + getVelY());
            }
            
        };
        
        Clock.addTask(gravity);
    }
    
    @Override
    public void processEvent(SpriteCollisionEvent sce){
        SpriteComponent sc = getSpriteComponent();
        if(sce.xlo){
            Dimension d = sc.getSize();
            double w = d.getWidth();
            setX(w - getWidth());
        }
        if(sce.xhi){
            setX(0);
        }
        if(sce.ylo){
            JOptionPane.showMessageDialog(sc, "You flew off into space");
            System.exit(0);
        }
        if(sce.yhi){
            JOptionPane.showMessageDialog(sc, "You missed the landing pad");
            System.exit(0);
        }
    }
    
}
